window.toggleSettings = function() { 
    document.getElementById('settingsOverlay').classList.toggle('active'); 
};

window.toggleLightMode = function() {
    const isLight = document.body.classList.toggle('light-mode');
    document.getElementById('modeBtn').innerText = isLight ? 'Light Mode' : 'Dark Mode';
};

window.toggleTimeFormat = function() {
    window.use24Hour = !window.use24Hour;
    document.getElementById('timeFormatBtn').innerText = window.use24Hour ? '24 Hour' : '12 Hour';
    if(typeof window.updateClock === 'function') window.updateClock();
    if(typeof window.renderDayGrid === 'function') window.renderDayGrid();
};
