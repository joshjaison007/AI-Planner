@echo off
echo ===================================================
echo     Liquid AI Planner - Initial Setup ^& Launch
echo ===================================================
echo.

:: 1. Check for Python
python --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo [ERROR] Python is not installed or not added to your system PATH.
    echo Please install Python ^(https://www.python.org/downloads/^) and ensure you check the box to 'Add Python to PATH'. Then restart this script!
    pause
    exit /b
)
echo [OK] Python detected.

:: 2. Check for Ollama
ollama --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo [ERROR] Ollama is not installed or the engine is not running.
    echo Please download and run the Ollama installer ^(https://ollama.com/download^) to utilize the native AI features. Let it run in the background, then restart this script!
    pause
    exit /b
)
echo [OK] Ollama base engine detected.

:: 3. Pull the AI Model
echo.
echo Pulling Llama3.1:8b AI neural model...
echo (If this is your first time, it may take several minutes depending on your internet speed. Please wait patiently!)
ollama pull llama3.1:8b

:: 4. Set up Virtual Environment
IF NOT EXIST venv (
    echo.
    echo Building highly isolated Python sandbox [venv] to keep your global OS clean...
    python -m venv venv
)
echo [OK] Sandbox configuration is healthy.

:: 5. Install Dependencies
echo.
echo Injecting required node packages from requirements.txt...
call venv\Scripts\pip install -r requirements.txt

:: 6. Launch App
echo.
echo ===================================================
echo             SYSTEM READY. BOOTING UI!
echo ===================================================
timeout /t 3 >nul

start http://localhost:8000
call venv\Scripts\python app.py

pause
